Create your own Google Chrome Theme here:
https://chrome.google.com/webstore/detail/ognfcdaekjfmdjhcjaacfapijblalleg

This folder and its contents represent a Google Chrome theme. Go to chrome://extensions to install this theme. Go to "chrome://settings" to uninstall this theme.